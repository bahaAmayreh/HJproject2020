
public class Person {
	private String ID;
	private String name;
	private String season;
	private String age;
	private String entryDate;
	private String eitDate;
	private String entryTime;
	private String exitTime;
	private String gender;
	private String passportIssue;
	private String visaIssue;
	private String nation;
	private String airline;
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSeason() {
		return season;
	}
	public void setSeason(String season) {
		this.season = season;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getEntryDate() {
		return entryDate;
	}
	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}
	public String getEitDate() {
		return eitDate;
	}
	public void setEitDate(String eitDate) {
		this.eitDate = eitDate;
	}
	public String getEntryTime() {
		return entryTime;
	}
	public void setEntryTime(String entryTime) {
		this.entryTime = entryTime;
	}
	public String getExitTime() {
		return exitTime;
	}
	public void setExitTime(String exitTime) {
		this.exitTime = exitTime;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPassportIssue() {
		return passportIssue;
	}
	public void setPassportIssue(String passportIssue) {
		this.passportIssue = passportIssue;
	}
	public String getVisaIssue() {
		return visaIssue;
	}
	public void setVisaIssue(String visaIssue) {
		this.visaIssue = visaIssue;
	}
	public String getNation() {
		return nation;
	}
	public void setNation(String nation) {
		this.nation = nation;
	}
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
}
